# fin — moteur de recherche

Node.js 24. Aucune dépendance externe pour les calculs.

    npm test
    npm run screen
    npm run collect -- --output output/snapshot.json

Le protocole complet est public/research/protocole.md.
La référence indépendante : python3 public/research/analyse-reference.py.

Prix figés au 16 octobre 2026. Aucun avantage prédictif validé.
